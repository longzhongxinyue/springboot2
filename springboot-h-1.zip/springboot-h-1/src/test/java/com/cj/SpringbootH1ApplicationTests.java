package com.cj;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.cj.entity.MyUser;
import com.cj.service.impl.UserServiceImpl;
import com.cj.util.MyStaticData;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringbootH1ApplicationTests {

//	@Test
//	public void contextLoads() {
//	}
	@Autowired
	MyStaticData staticData;
	@Autowired
	UserServiceImpl userServiceImpl;
	
	
//	@Test
//	public void MyStatic() {
//		System.out.println(staticData.getShopName());
//	}
	@Test
	public void selectUser() {
		MyUser u=	userServiceImpl.findByUserName("chenjie");
		System.out.println(u);
	}
}
