package com.cj.dao;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import com.cj.entity.MyUser;
public interface UserRepository extends JpaRepository<MyUser, Long> {
	
	MyUser findByUserName(String userName);
	
	MyUser findByUid(Long uid);
	
	//List<MyUser> findFirst3ByLastname(String lastname, Sort sort);
	List<MyUser> findFirst3ByUserName(String username, Sort sort);
}