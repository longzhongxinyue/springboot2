//package com.cj.util;
//
//import org.springframework.boot.context.properties.ConfigurationProperties;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.PropertySource;
///**
// * 绑定JavaBean  读取自定义配置文件
// * @author 陈杰
// *
// */
//@Configuration
//@PropertySource("classpath:demoText.properties")
//@ConfigurationProperties(prefix="demo")
//public class ReadPro {
//
//		private  String name;
//		
//		private int age;
//		
//		private String sex;
//
//		public String getName() {
//			return name;
//		}
//
//		public void setName(String name) {
//			this.name = name;
//		}
//
//		public int getAge() {
//			return age;
//		}
//
//		public void setAge(int age) {
//			this.age = age;
//		}
//
//		public String getSex() {
//			return sex;
//		}
//
//		public void setSex(String sex) {
//			this.sex = sex;
//		}
//		
//		
//		
//}
