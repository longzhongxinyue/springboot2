package com.cj.mvc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cj.entity.MyUser;
import com.cj.util.MyStaticData;
//import com.cj.util.ReadPro;

@RestController   //无法返回html/jsp   返回值为json.     Controller 可返回页面
public class HomeCfg {
	
	@Autowired
	MyStaticData staticData;

	@RequestMapping("/toHome")
	public String toHome(){
		System.out.println(staticData.getShopName());
		return null;
	}
	@RequestMapping("/tUser")
	public MyUser tUser(){
		return new MyUser();
	}
}
