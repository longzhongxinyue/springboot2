package com.cj.mvc;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cj.entity.MyUser;
import com.cj.service.UserService;

@RestController
public class MyTestCfg {

	@Autowired
	UserService userService;
		
	@RequestMapping("/getUser")
	//@Cacheable(value="user-key")
	public MyUser getUser(String  username) {
		MyUser user=userService.findByUserName(username);
	    return user;
	}
	@RequestMapping("/getUserByID")
	public MyUser getUserByID(long uid) {
		System.out.println(uid);
		MyUser user=userService.findByUid(uid);
	    return user;
	}
	
	@RequestMapping("/save")
	public boolean save(String username) {
		MyUser u=new MyUser();
		u.setUserName(username);
		 userService.save(u);
	    return true;
	}
	
	@RequestMapping("/login")
	public boolean login(MyUser u,HttpSession session){
		session.setAttribute("username", u.getUserName());
		return true;
	}
	
	@RequestMapping("/findAll")
	public List<MyUser> findAll(){
		
		return userService.findAll();
		
	}
	@RequestMapping("/findAllByPage")
	public Page<MyUser> findAllByPage(int page,int size,String sort){
		return userService.findAll(page, size, sort);
	}
}
