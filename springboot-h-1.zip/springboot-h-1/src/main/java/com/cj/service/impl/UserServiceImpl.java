package com.cj.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.cj.dao.UserRepository;
import com.cj.entity.MyUser;
import com.cj.service.UserService;
@Service
//@CacheConfig(cacheNames ="MyUser")
public class UserServiceImpl implements UserService {

	
	@Autowired
	UserRepository userRepository;
	
	@Override
	//@Cacheable(value="#myusers" )
	public MyUser findByUserName(String userName) {
		// TODO Auto-generated method stub
		return userRepository.findByUserName(userName);
	}

	@Override
	//@Cacheable(key="'uid'+#uid" )
	public MyUser findByUid(Long uid) {
		// TODO Auto-generated method stub
		System.out.println("若下面没出现“无缓存的时候调用”字样且能打印出数据表示测试成功"); 
		return userRepository.findByUid(uid);
	}

	@Override
	//@CachePut(key="'uid'+#user.uid" )
	public MyUser save(MyUser user) {
		// TODO Auto-generated method stub
		System.out.println("若下面没出现“无缓存的时候调用”字样且能打印出数据表示测试成功"); 
		return userRepository.save(user);
	}

	@Override
	public List<MyUser> findAll() {
		
		
		return userRepository.findAll();
	}

	@Override
	public Page<MyUser> findAll(int page, int size, String sort) {
//		 page=1;
//		 size=5;
//		 sort="uid";
	//	Sort realySort=new Sort(Direction.DESC,sort);
		Sort realySort=new Sort(sort);
		Pageable pageable = new PageRequest(page, size, realySort);
		
		Page<MyUser> pUser= userRepository.findAll(pageable);
		
		List<MyUser> list=userRepository.findFirst3ByUserName("bbbbb",realySort);
		
		return pUser;
	}
	
	
	
	
}
