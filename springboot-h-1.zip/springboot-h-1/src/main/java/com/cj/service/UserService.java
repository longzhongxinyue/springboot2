package com.cj.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.cj.entity.MyUser;

public interface UserService {

	MyUser findByUserName(String userName);
	
	MyUser findByUid(Long uid);
	
	MyUser save(MyUser user);
	
	List<MyUser> findAll();
	
	Page<MyUser> findAll(int page,int size,String sort);
}
