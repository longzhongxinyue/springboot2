package com.cj;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.cj.entity.MyUser;
import com.cj.rabbitmq.direct.DirectSender;
import com.cj.rabbitmq.fanout.FanoutSender;
import com.cj.rabbitmq.topic.TopicSender;


@RunWith(SpringRunner.class)
@SpringBootTest
public class RabbitMQTest {
	@Autowired
	private FanoutSender fanoutSender;
	@Autowired
	private TopicSender topicSender;
	@Autowired
	private DirectSender directSender;

//	@Test
//	public void testFanout() throws Exception {
//		MyUser u = new MyUser();
//		u.setUsername("the_first_test");
//		u.setPassword("123456");
//		while (true) {
//			fanoutSender.send(u);
//			Thread.sleep(1000);
//		}
//	}
	/**
	 * TOPIC测试
	 * 
	 * @throws Exception
	 */
//	@Test
//	public void testTopic() throws Exception {
//		MyUser u = new MyUser();
//		u.setUsername("the_first_test");
//		u.setPassword("123456");
//		topicSender.send(u);
//	}

	/**
	 * DIRECT测试
	 * 
	 * @throws Exception
	 */
//	@Test
//	public void testDirect() throws Exception {
//		MyUser u = new MyUser();
//		u.setUsername("the_first_test");
//		u.setPassword("123456");
//		directSender.send(u);
//	}

}
