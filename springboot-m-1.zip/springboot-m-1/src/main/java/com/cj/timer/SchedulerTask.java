package com.cj.timer;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
/**
 * 定时任务
 * @author 陈杰
 *
 */
@Component
public class SchedulerTask {

	private int count=0;
	
	@Scheduled(cron="*/6 * * * * ?")
	public void sayNum() {
		System.out.println("run time:"+count++);
		
	}
	
}
