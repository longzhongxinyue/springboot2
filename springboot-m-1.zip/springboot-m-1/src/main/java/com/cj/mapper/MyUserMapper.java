package com.cj.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.cj.entity.MyUser;
//@Mapper
public interface MyUserMapper {
    int deleteByPrimaryKey(Long uid);

    int insert(MyUser record);

    int insertSelective(MyUser record);
    
    MyUser selectByPrimaryKey(Long uid);

    int updateByPrimaryKeySelective(MyUser record);

    int updateByPrimaryKey(MyUser record);
}