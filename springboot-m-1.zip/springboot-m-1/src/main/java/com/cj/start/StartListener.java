package com.cj.start;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class StartListener implements ApplicationRunner{
	//@Autowired
	//private UserRepository userRepository;
	@Override
	public void run(ApplicationArguments arg0) throws Exception {
		System.out.println("系统启动");
	}
	

}
