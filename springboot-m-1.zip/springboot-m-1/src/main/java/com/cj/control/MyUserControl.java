package com.cj.control;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cj.entity.MyUser;
import com.cj.rabbitmq.fanout.FanoutSender;
import com.cj.service.Impl.MyUserServiceImpl;

/**
 * 
 * @author 陈杰
 *
 */
@RestController
@RequestMapping("/MyUser")
public class MyUserControl {

	@Autowired
	MyUserServiceImpl oMyUserServiceImpl;
	
	@RequestMapping("/index")
	public String index() {
		return "hello word xiugai";
	}
	
	@RequestMapping("/select")
	public MyUser select(String uid) {
		if(uid==null||uid=="") {
			return null;
		}
		MyUser oMyUser=oMyUserServiceImpl.selectByPrimaryKey(Long.valueOf(uid));
		return oMyUser;
	}
	@RequestMapping("/sendRabbit")
	public String sendRabbit() {
		FanoutSender send=new FanoutSender();
		MyUser u= new MyUser();
		u.setUsername("the_first_test");
		u.setPassword("123456");
		send.send(u);
		return null;
	}
}
