package com.cj.control;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
/**
 * 
 * @author 陈杰
 *
 */
@Controller
@RequestMapping("/jump")
public class JumpControl {

}
