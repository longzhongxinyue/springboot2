package com.cj.util;

import java.util.List;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
  * 加载yaml配置文件的方法
  * spring-boot更新到1.5.2版本后locations属性无法使用
  * @PropertySource注解只可以加载proprties文件,无法加载yaml文件
  * 故现在把数据放到application.yml文件中,spring-boot启动时会加载
  */
 @Component
 @ConfigurationProperties(prefix="carshop")
public class MyStaticData{
	 
	 private String shopName;
	 
	 private int openTime;
	 
	 private String[] clerk;
	 
	 private List<String> cars;
	 
	// private List<String> colors;
	 
	 private Map<String,String> price;

	public String getShopName() {
		return shopName;
	}
	//String类型的一定需要setter来接收属性值；maps, collections, 和 arrays 不需要
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public int getOpenTime() {
		return openTime;
	}

	public void setOpenTime(int openTime) {
		this.openTime = openTime;
	}

	public String[] getClerk() {
		return clerk;
	}

	public void setClerk(String[] clerk) {
		this.clerk = clerk;
	}

	public List<String> getCars() {
		return cars;
	}

	public void setCars(List<String> cars) {
		this.cars = cars;
	}

	public Map<String, String> getPrice() {
		return price;
	}

	public void setPrice(Map<String, String> price) {
		this.price = price;
	}
	 

	
}