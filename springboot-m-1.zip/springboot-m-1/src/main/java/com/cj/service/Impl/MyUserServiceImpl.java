package com.cj.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cj.entity.MyUser;
import com.cj.mapper.MyUserMapper;
import com.cj.service.MyUserService;
/**
 * 
 * @author 陈杰
 *
 */
@Service
public class MyUserServiceImpl implements MyUserService{

	@Autowired
	MyUserMapper oMyUserMapper;
	
	
	@Override
	public MyUser selectByPrimaryKey(Long uid) {
		
		return oMyUserMapper.selectByPrimaryKey(uid);
	}

}
