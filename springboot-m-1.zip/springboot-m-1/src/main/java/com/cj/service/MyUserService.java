package com.cj.service;

import com.cj.entity.MyUser;

public interface MyUserService {

	 MyUser selectByPrimaryKey(Long uid);
}
