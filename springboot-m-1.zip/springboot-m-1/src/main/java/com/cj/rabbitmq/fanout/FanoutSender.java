package com.cj.rabbitmq.fanout;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cj.entity.MyUser;
import com.cj.rabbitmq.RabbitConfig;
/**
 * Fanout 消息发送
 * @author 陈杰
 *
 */
@Component
public class FanoutSender {

	@Autowired
	private AmqpTemplate amqpTemplate; //springboot 提供的默认实现
	
	public void send(MyUser u) {
		amqpTemplate.convertAndSend(RabbitConfig.FANOUT_EXCHANGE,"",u);
	}
}
