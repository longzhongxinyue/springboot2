package com.cj.rabbitmq.fanout;
 
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import com.cj.entity.MyUser;
import com.cj.rabbitmq.RabbitConfig;
 
@Component
public class FanoutReceiver {
 
    // queues是指要监听的队列的名字
    @RabbitListener(queues = RabbitConfig.FANOUT_QUEUE1)
    public void receiveTopic1(MyUser user) {
        System.out.println("【receiveFanout1监听到消息】" + user);
    }
 
    @RabbitListener(queues = RabbitConfig.FANOUT_QUEUE2)
    public void receiveTopic2(MyUser user) {
        System.out.println("【receiveFanout2监听到消息】" + user);
    }
}
