//package com.cj.session;
//package com.cj.springboot_mybatis.session;
//
//import org.springframework.context.annotation.Configuration;
//import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;
//
///**
// * 
// * @author 陈杰
// *
// */
//@Configuration
//@EnableRedisHttpSession(maxInactiveIntervalInSeconds = 86400 * 30)
//public class SessionConfig {
//
//}
