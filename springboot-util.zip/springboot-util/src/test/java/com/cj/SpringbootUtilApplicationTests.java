package com.cj;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.cj.email.MailService;
import com.cj.util.MyStaticData;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringbootUtilApplicationTests {

//	@Test
//	public void contextLoads() {
//	}
//	@Autowired
//	MyStaticData staticData;

//	@Test
//	public void MyStaticTest() {
//		System.out.println("email::"+MyStaticData.addr);
//	}

	@Autowired
	private MailService MailService;

	@Test
	public void testSimpleMail() throws Exception {
		MailService.sendSimpleMail("1352611369@qq.com", "test simple mail", " hello this is simple mail");
	}

}
