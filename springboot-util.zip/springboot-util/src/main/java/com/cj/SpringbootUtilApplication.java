package com.cj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootUtilApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootUtilApplication.class, args);
	}

}
