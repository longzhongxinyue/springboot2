package com.cj.email;

public interface MailService {

	 public void sendSimpleMail(String to, String subject, String content);
	
}
