package com.cj.util;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix="my-ail")
public class MyStaticData {

	public  static String addr;
	
	public  void setAddr(String addr) {
		MyStaticData.addr = addr;
	}
	
	
}
