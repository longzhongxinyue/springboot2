# Getting Started

### Guides
The following guides illustrates how to use certain features concretely:

* [Handling Form Submission](https://spring.io/guides/gs/handling-form-submission/)

