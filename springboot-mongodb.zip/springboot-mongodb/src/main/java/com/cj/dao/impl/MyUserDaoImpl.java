package com.cj.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import com.cj.dao.MyUserDao;
import com.cj.entity.MyUser;

@Component
public class MyUserDaoImpl implements MyUserDao {

	@Autowired
	private MongoTemplate  mongoTemplate; 
	
	/**
	 *存
	 */
	@Override
	public void saveMyUser(MyUser u) {
		mongoTemplate.save(u);
	}
	/**
	 * 查
	 */
	@Override
	public MyUser findMyUserByUserName(String userName) {
		 Query query=new Query(Criteria.where("userName").is(userName));
		 MyUser u = mongoTemplate.findOne(query, MyUser.class);
		return u;
	}
	
	/**
	 * 改
	 */
	@Override
	public void updateMyUser(MyUser u) {
		Query query=new Query(Criteria.where("uid").is(u.getUid()));
		Update update= new Update().set("userName", u.getUserName()).set("passWord", u.getPassWord());
	    //更新查询返回结果集的第一条
        mongoTemplate.updateFirst(query,update,MyUser.class);
        //更新查询返回结果集的所有
        // mongoTemplate.updateMulti(query,update,MyUser.class);
		
	}

	/**
	 * 删
	 */
	@Override
	public void deleteMyUserByUid(Long uid) {
		 Query query=new Query(Criteria.where("uid").is(uid));
	     mongoTemplate.remove(query,MyUser.class);
	}

}
