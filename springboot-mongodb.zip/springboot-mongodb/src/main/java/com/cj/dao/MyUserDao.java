package com.cj.dao;

import com.cj.entity.MyUser;

public interface MyUserDao {

	public void saveMyUser(MyUser u);
	
	public MyUser findMyUserByUserName(String userName);
	
	public void updateMyUser(MyUser u) ;
	
	public void deleteMyUserByUid(Long uid);
	
}
