package com.cj;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.cj.entity.MyUser;
import com.cj.dao.MyUserDao;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MongoDBTest {
	@Autowired
	private MyUserDao MyUserDao;

//	@Test
//	public void testSaveMyUser() throws Exception {
//		MyUser MyUser = new MyUser();
//		MyUser.setUid(2l);
//		MyUser.setUserName("小明");
//		MyUser.setPassWord("fffooo123");
//		MyUserDao.saveMyUser(MyUser);
//	}

	@Test
	public void findMyUserByMyUserName() {
		MyUser MyUser = MyUserDao.findMyUserByUserName("小明");
		System.out.println("MyUser is " + MyUser);
	}

//	@Test
//	public void updateMyUser() {
//		MyUser MyUser = new MyUser();
//		MyUser.setUid(2l);
//		MyUser.setUserName("天空");
//		MyUser.setPassWord("fffxxxx");
//		MyUserDao.updateMyUser(MyUser);
//	}
//
//	@Test
//	public void deleteMyUserById() {
//		MyUserDao.deleteMyUserByUid(1l);
//	}
}
