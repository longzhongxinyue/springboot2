$(function(){
	
	alert(123132132);
})