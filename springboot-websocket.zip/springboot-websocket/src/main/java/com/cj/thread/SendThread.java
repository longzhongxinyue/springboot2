package com.cj.thread;

import com.cj.service.WebSocketServer;

public class SendThread extends Thread {

	private String message="websocket测试消息";
	
	@Override
	public void run() {
			
		System.out.println("websocket推送线程启动....");
		
			while(true) {
				try {
					Thread.sleep(50);
					if(WebSocketServer.getOnlineCount()>0) {
						WebSocketServer.onMessage(message, null);
						Thread.sleep(1000);
					}
					
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
		
	}
}
